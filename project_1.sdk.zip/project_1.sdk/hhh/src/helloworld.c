/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xil_cache.h"
#include "xcde_emc_bench.h"
#include "xtime_l.h"
#include "math.h"
#include "xdebug.h"
#define N 10
#define PI 3.1415926535897932384626433832795029
#define GenNUM 250*N
#define  Rmax 10
#define  Rmin 1

static int lfsr;
//float unimap[100]={283,294,268,272,202,246,327,300,309,318,305,264,264,209,293,283,256,261,326,305,326,281,322,203,323,241,338,258,255,251,285,335,308,205,263,281,331,261,294,335,295,302,205,323,308,266,296,329,283,330,287,210,294,331,242,331,292,338,243,254,327,339,205,297,265,270,326,268,319,283,334,297,211,326,242,310,325,257,258,264,278,212,268,245,243,275,305,305,328,268,329,243,204,303,257,329,303,269,248,253};
float unimap[100]={9.15,9.19,8.68,8.44,8.93,8.94,9.25,9.37,8.55,8.53,9.06,9.20,9.27,9.25,8.95,9.51,8.96,9.45,8.37,8.77,9.40,9.04,9.22,8.35,8.32,8.84,9.30,9.32,8.46,8.86,8.63,9.43,9.49,9.42,9.33,8.35,8.91,8.96,8.32,8.99,8.94,9.35,9.16,8.72,8.81,8.55,8.65,8.61,8.93,8.48,9.35,9.24,8.50,8.74,8.52,9.13,9.17,8.99,8.39,8.98,8.37,9.29,8.80,8.94,8.91,8.55,9.55,8.36,9.27,8.84,9.08,9.22,8.80,8.85,8.32,8.50,9.29,9.57,9.55,9.09,9.11,8.81,9.25,9.00,8.46,8.44,8.72,8.52,9.53,9.16,8.57,9.42,9.44,8.96,8.94,8.39,8.48,8.53,8.46,9.20};
int LFSRfunc(int load,int seed,int minn, int Rmaxmin){
    if(load ==1){
        lfsr = seed; //static
    }
    int bit;
    bit = ((lfsr >> 0) ^ (lfsr >> 1) ^ (lfsr >> 2) ^ (lfsr >> 3)) & 1;
    lfsr = (lfsr >> 1) | (bit << 15);
    return lfsr%(Rmaxmin)+minn;
}
float func_unite(float pop[N]){
    float re=0;
    int temppi,popselect;
    for(int i=0;i<N;i++){
        popselect = (int)pop[i];
        re = re + unimap[i*10+popselect];
    }
    return re;

}
float myerfinv03(float x){
    float temp,re;
    temp = x+0.261799388*x*x*x+0.143931731*x*x*x*x*x+0.097663620*x*x*x*x*x*x*x+0.073299079*x*x*x*x*x*x*x*x*x+0.058372501*x*x*x*x*x*x*x*x*x*x*x+0.048336063*x*x*x*x*x*x*x*x*x*x*x*x*x+0.041147395*x*x*x*x*x*x*x*x*x*x*x*x*x*x*x;
    re = temp*(sqrt(PI)/2);
    return re;

}
float myerf01(float x){
    float a1=0.278393,a2=0.230389,a3=0.000972,a4=0.078108;
    float t,rer;
    float txx,ttt;
    txx=x*x;
    t= 1+a1*x+a2*txx+a3*txx*x+a4*txx*txx;
    ttt = t*t;
    rer=1-1/(ttt*ttt);

    return rer;
}

float bpecDEbest1bin_rand_g(int seed,int iternum,int func_num){
    // �������
    float mu[N],sigma[N],mut,sigt;
    float best[N];
    float bestfit,xofffit;
    float los_l,win_l;
    float xoff[N];

    float F,Cr,tempF,templf;
    float rand_x1,rand_x2;
    float tempsqr; // Ҫ�г�ʼ���������
    int Rmaxmin,Rmed,Rmaxmin2;
    float erf1,erf2,sigF;
    int temp_lfsr;
    // ��ʼ��
    F= 0.7;//cinput.F;
    Cr = 0.9;//cinput.Cr;
    Rmed = 0.5*(Rmax+Rmin);
    Rmaxmin = Rmax-Rmin;
    Rmaxmin2 = 0.5*Rmaxmin;
    temp_lfsr = seed;
    templf = LFSRfunc(1,seed,Rmin,Rmaxmin);
    for(int i=0;i<N;i++){
        mu[i] = 0;
        sigma[i] = 10.0;
        // temp_lfsr = LFSRfunc(0,seed,Rmin,Rmaxmin);
        best[i] = (float)LFSRfunc(0,seed,Rmin,Rmaxmin);//lsfr_map(temp_lfsr,Rmin,Rmaxmin);//float(Rmin+rand()%(Rmaxmin+1));//chaos_map(rand_x,Rmin,Rmaxmin);
        xoff[i] = 0;
    }
    bestfit = func_unite(best);
    // if(tfnum==1){
    // 	bestfit = fitfunc_Rosenbrock(best);
    // }
    // else{
    // 	bestfit = fitfunc_Rastrigin(best);
    // }
    for(int i=1;i<iternum;i++){
        // ����
        for(int j=0;j<N;j++){
            tempsqr = sigma[j]*1.414213562;
            erf1 = myerf01((mu[j]-1)/(tempsqr));
            erf2 = myerf01((mu[j]+1)/(tempsqr));
            // temp_lfsr = LFSRfunc(temp_lfsr);
            rand_x1 = (float)LFSRfunc(0,seed,0,9999)/10000.0;//rand()/double(RAND_MAX);// ���������
            // temp_lfsr = LFSRfunc(temp_lfsr);
            rand_x2 =(float)LFSRfunc(0,seed,0,9999)/10000.0;//rand()/double(RAND_MAX);

             if(rand_x2>((0.2)*(i/iternum)+0.7)){
                tempF = F+(i/iternum)*0.2;
                xoff[j] = (tempF)*(((best[j]-Rmed)/(Rmaxmin2))-mu[j])+mu[j]-tempsqr*(tempF-1)*myerfinv03(-rand_x1*erf1+(rand_x1-1)*erf2)+(rand_x2-0.5);
                xoff[j] =xoff[j]*Rmaxmin2+Rmed;
            }
            else{
                xoff[j] = best[j];//-Rmed)/(0.5*Rmaxmin);
            }
            if(xoff[j]>Rmax){xoff[j]=Rmax;}
            if(xoff[j]<Rmin){xoff[j]=Rmin;} //���ַ����᲻�ϵ������߽磬Ȼ���޷�����
        }
        xofffit = func_unite(xoff);
        // if(tfnum==1){
        // 	xofffit = fitfunc_Rosenbrock(xoff);
        // }
        // else{
        // 	xofffit = fitfunc_Rastrigin(xoff);
        // }
        if(xofffit<bestfit){
            bestfit = xofffit;
        }
        for(int j=0;j<N;j++){
            // ת����PDF
            if(xofffit>bestfit){
                win_l = (best[j]-Rmed)/(Rmaxmin2);
                los_l = (xoff[j]-Rmed)/(Rmaxmin2);
            }else{
                win_l = (xoff[j]-Rmed)/(Rmaxmin2);
                los_l = (best[j]-Rmed)/(Rmaxmin2);
                best[j] = xoff[j];
            }

            mut = mu[j];
            mu[j] = mu[j]+(win_l-los_l)/10.0;
            sigt = sigma[j]*sigma[j]+mut*mut-mu[j]*mu[j]+(win_l*win_l-los_l*los_l)/10.0;
            if(sigt<=0){
                sigma[j] =10.0;// ���ܵ���0 ���������ֲ�������
            }
            else{
                sigma[j] =sqrt(sigt);
            }
        }
    }
    return bestfit;
}

int main()
{
	XTime tEnd, tCur,tCurrand;
		float A[110],B[110],meanfit3=0,meanfpga=0,bestfit3;
		float tUsed,tUsedarm,tallused=0,tallusedarm=0;
		int seed,intermax;

	    init_platform();
	    XTime_GetTime(&tCurrand);		//��ȡ��ʼʱ��
		srand((unsigned)tCurrand );
		 print("\nAAAAAAAA\n\r");
		for(int i=0;i<110;i++){
			A[i]=0;
			if(i<100){
				A[i]=unimap[i];
			}
		}

		intermax =1000;
		for(int k=0;k<51;k++){

			seed = (int)(1+rand()%(10000))+100;
			A[110-3] =seed;
			A[110-4] = intermax;

			XTime_GetTime(&tCur);		//��ȡ��ʼʱ��
			bestfit3  = bpecDEbest1bin_rand_g(seed,intermax,intermax);
			XTime_GetTime(&tEnd);
			tUsedarm=(float)((tEnd-tCur)*1000)/(COUNTS_PER_SECOND);
			tallusedarm = tallusedarm + tUsedarm;
	            printf(" %f ",bestfit3);
			meanfit3 = meanfit3 + bestfit3;
//			A[5] = 2;
//			A[6] = -5.12;
//			A[7] = 5.12;
	//		for(int i=0;i<10;i++){
	//			printf("%f ",A[i]);
	//		}
	//		 print("\n\r");
			XCde_emc_bench hlsconv;
			XCde_emc_bench_Config *ExamplePtr;


	//		printf("Look up the device configuration.\n");
			ExamplePtr=XCde_emc_bench_LookupConfig(XPAR_CDE_EMC_BENCH_0_DEVICE_ID);
			if(!ExamplePtr){
				printf("Error, lookup failed!");
				return XST_FAILURE;
			}

	//		printf("Initialize the Device\n");
			int status=XCde_emc_bench_CfgInitialize(&hlsconv,ExamplePtr);
			if(status!=XST_SUCCESS)
			{
				printf("Error, can't initialize accelerator.\n");
				return XST_FAILURE;
			}
			/*
			int status=XTest_Initialize(&hlsconv, XPAR_TEST_0_DEVICE_ID);
			if(status!=XST_SUCCESS)
			{
				printf("Error, can't initialize accelerator.\n");
				return XST_FAILURE;
			}
			*/

			Xil_DCacheFlushRange((u32)A,110*sizeof(float));  // Cache
			Xil_DCacheFlushRange((u32)B,110*sizeof(float));

			XCde_emc_bench_Set_A(&hlsconv,(u32)A);  // ����
			XCde_emc_bench_Set_B(&hlsconv,(u32)B);

			XTime_GetTime(&tCur);		//��ȡ��ʼʱ��
			XCde_emc_bench_Start(&hlsconv);              // start
			while(XCde_emc_bench_IsDone(&hlsconv)==0);   // done
			XTime_GetTime(&tEnd);
			tUsed=(float)((tEnd-tCur)*1000)/(COUNTS_PER_SECOND);
			tallused = tallused + tUsed;
			Xil_DCacheInvalidateRange((u32)B,110*sizeof(float));
			meanfpga = meanfpga + B[5];
//	//		for(int i=0;i<5;i++){
//			printf("%f ",B[3]);
//	//		}

		 }
		 printf("\nHW ALL time is %lfms\n",tallused);
		 printf("\nARM ALL time is %lfms\n",tallusedarm);
		 printf("\nARM ALL val is %lf\n",meanfit3);
		 printf("\nHW ALL val is %lf\n",meanfpga);
	//		print("\n=======\n\r");
	    cleanup_platform();
    return 0;
}
